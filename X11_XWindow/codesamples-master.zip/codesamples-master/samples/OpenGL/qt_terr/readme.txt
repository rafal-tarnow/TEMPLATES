Extract all into a single directory

Execute with
# terrain <terrain>.ter

Key mapping:
[V] Change camera mode
[H] Frustum Culling on/off
[L] Level of Detail triangle reduction on/off
[F] Polygonfilling/Wireframe on/off
[+] increase max. Level of Detail
[-] decrease max. Level of Detail
[S] Screenshot
<SPACE> pause/restart animation