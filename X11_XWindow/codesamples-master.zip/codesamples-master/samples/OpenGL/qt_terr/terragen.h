#ifndef TERRAGEN_H
#define TERRAGEN_H

int read_terrain(char const *filename, double **pbuffer, int *width, int *height, double *scale);

#endif/*TERRAGEN*/
